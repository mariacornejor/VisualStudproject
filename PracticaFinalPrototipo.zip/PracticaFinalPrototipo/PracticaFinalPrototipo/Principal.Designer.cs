﻿
namespace PracticaFinalPrototipo
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCrear = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelEstadoPag = new System.Windows.Forms.Label();
            this.buttonAdelante = new System.Windows.Forms.Button();
            this.buttonAtras = new System.Windows.Forms.Button();
            this.labelP10 = new System.Windows.Forms.Label();
            this.labelP9 = new System.Windows.Forms.Label();
            this.labelP8 = new System.Windows.Forms.Label();
            this.labelP7 = new System.Windows.Forms.Label();
            this.labelP6 = new System.Windows.Forms.Label();
            this.labelP5 = new System.Windows.Forms.Label();
            this.labelP4 = new System.Windows.Forms.Label();
            this.labelP3 = new System.Windows.Forms.Label();
            this.labelP2 = new System.Windows.Forms.Label();
            this.labelP1 = new System.Windows.Forms.Label();
            this.pictureBoxProducto9 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxProducto0 = new System.Windows.Forms.PictureBox();
            this.buttonSalir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCarrito)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto0)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonMicuenta
            // 
            this.buttonMicuenta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // buttonSalirCuenta
            // 
            this.buttonSalirCuenta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // buttonIniciarSesion
            // 
            this.buttonIniciarSesion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // buttonGestionProductos
            // 
            this.buttonGestionProductos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGestionProductos.Click += new System.EventHandler(this.buttonGestionProductos_Click);
            // 
            // buttonGestionClientes
            // 
            this.buttonGestionClientes.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // buttonCrear
            // 
            this.buttonCrear.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.buttonCrear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(231)))), ((int)(((byte)(231)))));
            this.buttonCrear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCrear.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCrear.Location = new System.Drawing.Point(1601, 293);
            this.buttonCrear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonCrear.Name = "buttonCrear";
            this.buttonCrear.Size = new System.Drawing.Size(273, 516);
            this.buttonCrear.TabIndex = 2;
            this.buttonCrear.Text = "Crear tu propio pastel";
            this.buttonCrear.UseVisualStyleBackColor = false;
            this.buttonCrear.Click += new System.EventHandler(this.buttonCrear_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.labelEstadoPag);
            this.panel1.Controls.Add(this.buttonAdelante);
            this.panel1.Controls.Add(this.buttonAtras);
            this.panel1.Controls.Add(this.labelP10);
            this.panel1.Controls.Add(this.labelP9);
            this.panel1.Controls.Add(this.labelP8);
            this.panel1.Controls.Add(this.labelP7);
            this.panel1.Controls.Add(this.labelP6);
            this.panel1.Controls.Add(this.labelP5);
            this.panel1.Controls.Add(this.labelP4);
            this.panel1.Controls.Add(this.labelP3);
            this.panel1.Controls.Add(this.labelP2);
            this.panel1.Controls.Add(this.labelP1);
            this.panel1.Controls.Add(this.pictureBoxProducto9);
            this.panel1.Controls.Add(this.pictureBoxProducto8);
            this.panel1.Controls.Add(this.pictureBoxProducto7);
            this.panel1.Controls.Add(this.pictureBoxProducto6);
            this.panel1.Controls.Add(this.pictureBoxProducto3);
            this.panel1.Controls.Add(this.pictureBoxProducto4);
            this.panel1.Controls.Add(this.pictureBoxProducto2);
            this.panel1.Controls.Add(this.pictureBoxProducto5);
            this.panel1.Controls.Add(this.pictureBoxProducto1);
            this.panel1.Controls.Add(this.pictureBoxProducto0);
            this.panel1.Location = new System.Drawing.Point(90, 188);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1410, 1069);
            this.panel1.TabIndex = 3;
            // 
            // labelEstadoPag
            // 
            this.labelEstadoPag.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelEstadoPag.AutoSize = true;
            this.labelEstadoPag.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEstadoPag.Location = new System.Drawing.Point(690, 833);
            this.labelEstadoPag.Name = "labelEstadoPag";
            this.labelEstadoPag.Size = new System.Drawing.Size(21, 23);
            this.labelEstadoPag.TabIndex = 22;
            this.labelEstadoPag.Text = "0";
            // 
            // buttonAdelante
            // 
            this.buttonAdelante.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonAdelante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(231)))), ((int)(((byte)(231)))));
            this.buttonAdelante.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAdelante.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonAdelante.Location = new System.Drawing.Point(773, 825);
            this.buttonAdelante.Name = "buttonAdelante";
            this.buttonAdelante.Size = new System.Drawing.Size(137, 38);
            this.buttonAdelante.TabIndex = 21;
            this.buttonAdelante.Text = "1";
            this.buttonAdelante.UseVisualStyleBackColor = false;
            this.buttonAdelante.Click += new System.EventHandler(this.buttonAdelante_Click);
            // 
            // buttonAtras
            // 
            this.buttonAtras.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonAtras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(231)))), ((int)(((byte)(231)))));
            this.buttonAtras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAtras.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonAtras.Location = new System.Drawing.Point(493, 825);
            this.buttonAtras.Name = "buttonAtras";
            this.buttonAtras.Size = new System.Drawing.Size(137, 38);
            this.buttonAtras.TabIndex = 20;
            this.buttonAtras.Text = "-1";
            this.buttonAtras.UseVisualStyleBackColor = false;
            this.buttonAtras.Click += new System.EventHandler(this.buttonAtras_Click);
            // 
            // labelP10
            // 
            this.labelP10.AutoSize = true;
            this.labelP10.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP10.Location = new System.Drawing.Point(1135, 763);
            this.labelP10.Name = "labelP10";
            this.labelP10.Size = new System.Drawing.Size(48, 25);
            this.labelP10.TabIndex = 19;
            this.labelP10.Text = "P10";
            this.labelP10.Visible = false;
            // 
            // labelP9
            // 
            this.labelP9.AutoSize = true;
            this.labelP9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelP9.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP9.Location = new System.Drawing.Point(855, 763);
            this.labelP9.Name = "labelP9";
            this.labelP9.Size = new System.Drawing.Size(36, 25);
            this.labelP9.TabIndex = 18;
            this.labelP9.Text = "P9";
            this.labelP9.Visible = false;
            // 
            // labelP8
            // 
            this.labelP8.AutoSize = true;
            this.labelP8.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP8.Location = new System.Drawing.Point(575, 763);
            this.labelP8.Name = "labelP8";
            this.labelP8.Size = new System.Drawing.Size(36, 25);
            this.labelP8.TabIndex = 17;
            this.labelP8.Text = "P8";
            this.labelP8.Visible = false;
            // 
            // labelP7
            // 
            this.labelP7.AutoSize = true;
            this.labelP7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP7.Location = new System.Drawing.Point(295, 763);
            this.labelP7.Name = "labelP7";
            this.labelP7.Size = new System.Drawing.Size(36, 25);
            this.labelP7.TabIndex = 16;
            this.labelP7.Text = "P7";
            this.labelP7.Visible = false;
            // 
            // labelP6
            // 
            this.labelP6.AutoSize = true;
            this.labelP6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP6.Location = new System.Drawing.Point(15, 763);
            this.labelP6.Name = "labelP6";
            this.labelP6.Size = new System.Drawing.Size(36, 25);
            this.labelP6.TabIndex = 15;
            this.labelP6.Text = "P6";
            this.labelP6.Visible = false;
            // 
            // labelP5
            // 
            this.labelP5.AutoSize = true;
            this.labelP5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelP5.Location = new System.Drawing.Point(1135, 357);
            this.labelP5.Name = "labelP5";
            this.labelP5.Size = new System.Drawing.Size(36, 25);
            this.labelP5.TabIndex = 14;
            this.labelP5.Text = "P5";
            this.labelP5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelP5.Visible = false;
            // 
            // labelP4
            // 
            this.labelP4.AutoSize = true;
            this.labelP4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelP4.Location = new System.Drawing.Point(855, 357);
            this.labelP4.Name = "labelP4";
            this.labelP4.Size = new System.Drawing.Size(36, 25);
            this.labelP4.TabIndex = 13;
            this.labelP4.Text = "P4";
            this.labelP4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelP4.Visible = false;
            // 
            // labelP3
            // 
            this.labelP3.AutoSize = true;
            this.labelP3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelP3.Location = new System.Drawing.Point(575, 357);
            this.labelP3.Name = "labelP3";
            this.labelP3.Size = new System.Drawing.Size(36, 25);
            this.labelP3.TabIndex = 12;
            this.labelP3.Text = "P3";
            this.labelP3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelP3.Visible = false;
            // 
            // labelP2
            // 
            this.labelP2.AutoSize = true;
            this.labelP2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelP2.Location = new System.Drawing.Point(295, 357);
            this.labelP2.Name = "labelP2";
            this.labelP2.Size = new System.Drawing.Size(36, 25);
            this.labelP2.TabIndex = 11;
            this.labelP2.Text = "P2";
            this.labelP2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelP2.Visible = false;
            // 
            // labelP1
            // 
            this.labelP1.AutoSize = true;
            this.labelP1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelP1.Location = new System.Drawing.Point(15, 357);
            this.labelP1.Name = "labelP1";
            this.labelP1.Size = new System.Drawing.Size(36, 25);
            this.labelP1.TabIndex = 10;
            this.labelP1.Text = "P1";
            this.labelP1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelP1.Visible = false;
            // 
            // pictureBoxProducto9
            // 
            this.pictureBoxProducto9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto9.Location = new System.Drawing.Point(1140, 434);
            this.pictureBoxProducto9.Name = "pictureBoxProducto9";
            this.pictureBoxProducto9.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto9.TabIndex = 9;
            this.pictureBoxProducto9.TabStop = false;
            this.pictureBoxProducto9.Click += new System.EventHandler(this.pictureBoxProducto9_Click);
            // 
            // pictureBoxProducto8
            // 
            this.pictureBoxProducto8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto8.Location = new System.Drawing.Point(860, 434);
            this.pictureBoxProducto8.Name = "pictureBoxProducto8";
            this.pictureBoxProducto8.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto8.TabIndex = 8;
            this.pictureBoxProducto8.TabStop = false;
            this.pictureBoxProducto8.Click += new System.EventHandler(this.pictureBoxProducto8_Click);
            // 
            // pictureBoxProducto7
            // 
            this.pictureBoxProducto7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto7.Location = new System.Drawing.Point(580, 434);
            this.pictureBoxProducto7.Name = "pictureBoxProducto7";
            this.pictureBoxProducto7.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto7.TabIndex = 7;
            this.pictureBoxProducto7.TabStop = false;
            this.pictureBoxProducto7.Click += new System.EventHandler(this.pictureBoxProducto7_Click);
            // 
            // pictureBoxProducto6
            // 
            this.pictureBoxProducto6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto6.Location = new System.Drawing.Point(300, 434);
            this.pictureBoxProducto6.Name = "pictureBoxProducto6";
            this.pictureBoxProducto6.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto6.TabIndex = 6;
            this.pictureBoxProducto6.TabStop = false;
            this.pictureBoxProducto6.Click += new System.EventHandler(this.pictureBoxProducto6_Click);
            // 
            // pictureBoxProducto3
            // 
            this.pictureBoxProducto3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto3.Location = new System.Drawing.Point(860, 28);
            this.pictureBoxProducto3.Name = "pictureBoxProducto3";
            this.pictureBoxProducto3.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto3.TabIndex = 5;
            this.pictureBoxProducto3.TabStop = false;
            this.pictureBoxProducto3.Click += new System.EventHandler(this.pictureBoxProducto3_Click);
            // 
            // pictureBoxProducto4
            // 
            this.pictureBoxProducto4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto4.Location = new System.Drawing.Point(1140, 28);
            this.pictureBoxProducto4.Name = "pictureBoxProducto4";
            this.pictureBoxProducto4.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto4.TabIndex = 4;
            this.pictureBoxProducto4.TabStop = false;
            this.pictureBoxProducto4.Click += new System.EventHandler(this.pictureBoxProducto4_Click);
            // 
            // pictureBoxProducto2
            // 
            this.pictureBoxProducto2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto2.Location = new System.Drawing.Point(580, 28);
            this.pictureBoxProducto2.Name = "pictureBoxProducto2";
            this.pictureBoxProducto2.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto2.TabIndex = 3;
            this.pictureBoxProducto2.TabStop = false;
            this.pictureBoxProducto2.Click += new System.EventHandler(this.pictureBoxProducto2_Click);
            // 
            // pictureBoxProducto5
            // 
            this.pictureBoxProducto5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto5.Location = new System.Drawing.Point(20, 434);
            this.pictureBoxProducto5.Name = "pictureBoxProducto5";
            this.pictureBoxProducto5.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto5.TabIndex = 2;
            this.pictureBoxProducto5.TabStop = false;
            this.pictureBoxProducto5.Click += new System.EventHandler(this.pictureBoxProducto5_Click);
            // 
            // pictureBoxProducto1
            // 
            this.pictureBoxProducto1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto1.Location = new System.Drawing.Point(300, 28);
            this.pictureBoxProducto1.Name = "pictureBoxProducto1";
            this.pictureBoxProducto1.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto1.TabIndex = 1;
            this.pictureBoxProducto1.TabStop = false;
            this.pictureBoxProducto1.Click += new System.EventHandler(this.pictureBoxProducto1_Click);
            // 
            // pictureBoxProducto0
            // 
            this.pictureBoxProducto0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxProducto0.Location = new System.Drawing.Point(20, 28);
            this.pictureBoxProducto0.Name = "pictureBoxProducto0";
            this.pictureBoxProducto0.Size = new System.Drawing.Size(248, 326);
            this.pictureBoxProducto0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxProducto0.TabIndex = 0;
            this.pictureBoxProducto0.TabStop = false;
            this.pictureBoxProducto0.Click += new System.EventHandler(this.pictureBoxProducto0_Click);
            // 
            // buttonSalir
            // 
            this.buttonSalir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(231)))), ((int)(((byte)(231)))));
            this.buttonSalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSalir.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Bold);
            this.buttonSalir.Location = new System.Drawing.Point(1601, 979);
            this.buttonSalir.Name = "buttonSalir";
            this.buttonSalir.Size = new System.Drawing.Size(273, 70);
            this.buttonSalir.TabIndex = 4;
            this.buttonSalir.Text = "Salir";
            this.buttonSalir.UseVisualStyleBackColor = false;
            this.buttonSalir.Click += new System.EventHandler(this.buttonSalir_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(58, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(466, 56);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nuestros Productos";
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonSalir);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonCrear);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Principal";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "+";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Controls.SetChildIndex(this.buttonCrear, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.buttonSalir, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCarrito)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxProducto0)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }





        #endregion

        private System.Windows.Forms.Button buttonCrear;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonSalir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelP10;
        private System.Windows.Forms.Label labelP9;
        private System.Windows.Forms.Label labelP8;
        private System.Windows.Forms.Label labelP7;
        private System.Windows.Forms.Label labelP6;
        private System.Windows.Forms.Label labelP5;
        private System.Windows.Forms.Label labelP4;
        private System.Windows.Forms.Label labelP3;
        private System.Windows.Forms.Label labelP2;
        private System.Windows.Forms.Label labelP1;
        private System.Windows.Forms.PictureBox pictureBoxProducto9;
        private System.Windows.Forms.PictureBox pictureBoxProducto8;
        private System.Windows.Forms.PictureBox pictureBoxProducto7;
        private System.Windows.Forms.PictureBox pictureBoxProducto6;
        private System.Windows.Forms.PictureBox pictureBoxProducto3;
        private System.Windows.Forms.PictureBox pictureBoxProducto4;
        private System.Windows.Forms.PictureBox pictureBoxProducto2;
        private System.Windows.Forms.PictureBox pictureBoxProducto5;
        private System.Windows.Forms.PictureBox pictureBoxProducto1;
        private System.Windows.Forms.PictureBox pictureBoxProducto0;
        private System.Windows.Forms.Label labelEstadoPag;
        private System.Windows.Forms.Button buttonAdelante;
        private System.Windows.Forms.Button buttonAtras;
    }
}